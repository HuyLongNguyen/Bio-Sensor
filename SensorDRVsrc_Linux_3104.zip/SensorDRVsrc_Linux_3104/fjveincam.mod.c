#include <linux/module.h>
#define INCLUDE_VERMAGIC
#include <linux/build-salt.h>
#include <linux/elfnote-lto.h>
#include <linux/vermagic.h>
#include <linux/compiler.h>

BUILD_SALT;
BUILD_LTO_INFO;

MODULE_INFO(vermagic, VERMAGIC_STRING);
MODULE_INFO(name, KBUILD_MODNAME);

__visible struct module __this_module
__section(".gnu.linkonce.this_module") = {
	.name = KBUILD_MODNAME,
	.init = init_module,
#ifdef CONFIG_MODULE_UNLOAD
	.exit = cleanup_module,
#endif
	.arch = MODULE_ARCH_INIT,
};

#ifdef CONFIG_RETPOLINE
MODULE_INFO(retpoline, "Y");
#endif

static const struct modversion_info ____versions[]
__used __section("__versions") = {
	{ 0x38f431f2, "module_layout" },
	{ 0x46fb29a7, "usb_deregister" },
	{ 0x417519dd, "usb_register_driver" },
	{ 0x328a05f1, "strncpy" },
	{ 0x7892ea7f, "usb_control_msg" },
	{ 0x5f754e5a, "memset" },
	{ 0xae353d77, "arm_copy_from_user" },
	{ 0x6e2c8701, "usb_clear_halt" },
	{ 0x2cfde9a2, "warn_slowpath_fmt" },
	{ 0x51a910c0, "arm_copy_to_user" },
	{ 0x9ce728a8, "usb_bulk_msg" },
	{ 0x6cdabca, "current_time" },
	{ 0xc358aaf8, "snprintf" },
	{ 0x3d9183af, "usb_register_dev" },
	{ 0x79df44a3, "usb_get_dev" },
	{ 0x77f6f183, "kmalloc_order_trace" },
	{ 0xde4bf88b, "__mutex_init" },
	{ 0xa12d6e96, "kmem_cache_alloc_trace" },
	{ 0x6d0b5a7f, "kmalloc_caches" },
	{ 0x8f678b07, "__stack_chk_guard" },
	{ 0x92997ed8, "_printk" },
	{ 0x3ea1b6e4, "__stack_chk_fail" },
	{ 0x49970de8, "finish_wait" },
	{ 0x647af474, "prepare_to_wait_event" },
	{ 0x8ddd8aad, "schedule_timeout" },
	{ 0xfe487975, "init_wait_entry" },
	{ 0x5bbe49f4, "__init_waitqueue_head" },
	{ 0x800473f, "__cond_resched" },
	{ 0xabfc563c, "usb_find_interface" },
	{ 0x3dcf1ffa, "__wake_up" },
	{ 0x9618ede0, "mutex_unlock" },
	{ 0x37a0cba, "kfree" },
	{ 0xcddca8da, "usb_driver_release_interface" },
	{ 0x143c7817, "_dev_info" },
	{ 0x828ce6bb, "mutex_lock" },
	{ 0x355983df, "usb_deregister_dev" },
	{ 0xb1ad28e0, "__gnu_mcount_nc" },
};

MODULE_INFO(depends, "");

MODULE_ALIAS("usb:v04C5p1084d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04C5p125Ad*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04C5p1526d*dc*dsc*dp*ic*isc*ip*in*");
MODULE_ALIAS("usb:v04C5p1527d*dc*dsc*dp*ic*isc*ip*in*");

MODULE_INFO(srcversion, "973425EBFB657E552A2B981");
