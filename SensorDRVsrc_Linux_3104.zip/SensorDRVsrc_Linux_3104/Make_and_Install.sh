#!/bin/bash
yes | sudo apt-get install raspberrypi-kernel-headers

echo '
obj-m = fjveincam.o
VERSION = $(shell uname -r)
KERNDIR ?= /usr/src/linux-headers-$(VERSION)
MAKE := make -C $(KERNDIR) M=$(shell pwd)

all:
	@if test -f $(KERNDIR)/Makefile; then \
		$(MAKE) modules; \
	else \
		echo "Path \"$(KERNDIR)\" not found."; \
	fi

install:
	@$(MAKE) modules_install

clean:
	@$(MAKE) clean' > Makefile

sudo make clean
# sudo rm -r /lib/modules/$(uname -r)/extra
# sudo rm /dev/usb/fjveincam0

sudo make
echo "---------------->Installing driver"
sudo mkdir /lib/modules/$(uname -r)/extra
sudo cp fjveincam.ko /lib/modules/$(uname -r)/extra/
sudo mkdir -p /dev/usb
sudo mknod -m 666 /dev/usb/fjveincam0 c 180 160
sudo /sbin/depmod -a &> /dev/null
sudo /sbin/modprobe fjveincam
sudo cp rc.local /etc/



